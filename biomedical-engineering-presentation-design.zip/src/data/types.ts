export type Layout = "title" | "section" | "content" | "gallery" | "quiz" | "final";

export type Slide = {
  id: string;
  layout: Layout;
  part: 0 | 1 | 2 | 3;
  title: string;
  subtitle?: string;
  extra?: string;
  bullets: string[];
  notes: string;
  topic: string;
  video?: string;
  images: string[];
};

export type Def = [
  layout: Layout,
  topic: string,
  title: string,
  bullets: string[],
  notes: string,
  opts?: { video?: string; n?: number; subtitle?: string; extra?: string }
];
