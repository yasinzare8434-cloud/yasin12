import { pickImages } from "../lib/media";
import { deck1 } from "./deck1";
import { deck2 } from "./deck2";
import { deck3 } from "./deck3";
import type { Def, Slide } from "./types";

const defaultN: Record<string, number> = { title: 8, section: 8, content: 9, gallery: 20, quiz: 0, final: 0 };

function build(): Slide[] {
  const all: Def[] = [...deck1, ...deck2, ...deck3];
  let part: 0 | 1 | 2 | 3 = 0;
  return all.map((d, i) => {
    const [layout, topic, title, bullets, notes, opts = {}] = d;
    if (layout === "section") part = (part + 1) as 1 | 2 | 3;
    const n = layout === "gallery" ? 20 : opts.n ?? defaultN[layout];
    // slides with a video use the big mosaic cell for the video => one image fewer
    const count = opts.video ? 4 : n;
    return {
      id: "s" + (i + 1),
      layout,
      part,
      title,
      subtitle: opts.subtitle,
      extra: opts.extra,
      bullets,
      notes,
      topic,
      video: opts.video,
      images: count > 0 ? pickImages(topic, count) : [],
    };
  });
}

export const initialSlides: Slide[] = build();
