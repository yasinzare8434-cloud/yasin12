import { useCallback, useEffect, useRef, useState } from "react";
import SlideView from "./components/SlideView";
import { initialSlides } from "./data/slides";
import type { Slide } from "./data/types";
import { VIDEOS } from "./lib/media";
import { PART_COLORS } from "./lib/theme";

const KEY = "deck-v4";
const W = 1280, H = 720;

function load(): { slides: Slide[]; notes: boolean } {
  try {
    const raw = localStorage.getItem(KEY);
    if (raw) {
      const j = JSON.parse(raw);
      if (Array.isArray(j.slides) && j.slides.length) return { slides: j.slides, notes: !!j.notes };
    }
  } catch { /* ignore */ }
  return { slides: initialSlides, notes: true };
}

export default function App() {
  const init = useRef(load());
  const [slides, setSlides] = useState<Slide[]>(init.current.slides);
  const [cur, setCur] = useState(0);
  const [edit, setEdit] = useState(false);
  const [notesOpen, setNotesOpen] = useState(init.current.notes);
  const [overview, setOverview] = useState(false);
  const [present, setPresent] = useState(false);
  const [light, setLight] = useState<string | null>(null);
  const [exp, setExp] = useState<{ p: number; msg: string } | null>(null);
  const [scale, setScale] = useState(1);
  const stageBox = useRef<HTMLDivElement>(null);

  const total = slides.length;
  const s = slides[Math.min(cur, total - 1)];
  const imgCount = slides.reduce((a, x) => a + x.images.length, 0);
  const vidCount = new Set(slides.map((x) => x.video).filter(Boolean)).size;

  // persist
  useEffect(() => {
    const t = setTimeout(() => {
      try { localStorage.setItem(KEY, JSON.stringify({ slides, notes: notesOpen })); } catch { /* quota */ }
    }, 400);
    return () => clearTimeout(t);
  }, [slides, notesOpen]);

  // scale stage
  useEffect(() => {
    const el = stageBox.current;
    if (!el) return;
    const fit = () => setScale(Math.min((el.clientWidth - 8) / W, (el.clientHeight - 8) / H));
    fit();
    const ro = new ResizeObserver(fit);
    ro.observe(el);
    return () => ro.disconnect();
  }, [present, notesOpen, overview, edit]);

  const go = useCallback((d: number) => setCur((c) => Math.max(0, Math.min(slides.length - 1, c + d))), [slides.length]);

  const toggleFs = useCallback(async () => {
    if (!document.fullscreenElement) {
      try { await document.documentElement.requestFullscreen(); } catch { /* ignore */ }
      setPresent(true);
    } else {
      await document.exitFullscreen();
      setPresent(false);
    }
  }, []);

  useEffect(() => {
    const onFs = () => { if (!document.fullscreenElement) setPresent(false); };
    document.addEventListener("fullscreenchange", onFs);
    return () => document.removeEventListener("fullscreenchange", onFs);
  }, []);

  useEffect(() => {
    const onKey = (e: KeyboardEvent) => {
      const el = e.target as HTMLElement;
      if (el && (el.isContentEditable || /INPUT|TEXTAREA|SELECT/.test(el.tagName))) return;
      if (e.key === "ArrowLeft" || e.key === "PageDown" || e.key === " ") { e.preventDefault(); go(1); }
      else if (e.key === "ArrowRight" || e.key === "PageUp") { e.preventDefault(); go(-1); }
      else if (e.key === "Home") setCur(0);
      else if (e.key === "End") setCur(slides.length - 1);
      else if (e.key.toLowerCase() === "n") setNotesOpen((v) => !v);
      else if (e.key.toLowerCase() === "f") toggleFs();
      else if (e.key.toLowerCase() === "e") setEdit((v) => !v);
      else if (e.key === "Escape") setLight(null);
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [go, slides.length, toggleFs]);

  const patch = (p: Partial<Slide>) => setSlides((arr) => arr.map((x, i) => (i === cur ? { ...x, ...p } : x)));

  const addSlide = () => {
    const ns: Slide = { id: "n" + Date.now(), layout: "content", part: s.part, title: "عنوان اسلاید جدید", bullets: ["نکته اول", "نکته دوم"], notes: "متن سخنرانی این اسلاید را اینجا بنویسید…", topic: s.topic, images: [] };
    setSlides((a) => [...a.slice(0, cur + 1), ns, ...a.slice(cur + 1)]);
    setCur(cur + 1);
  };
  const dupSlide = () => {
    const ns = { ...s, id: "d" + Date.now() };
    setSlides((a) => [...a.slice(0, cur + 1), ns, ...a.slice(cur + 1)]);
    setCur(cur + 1);
  };
  const delSlide = (i = cur) => {
    if (slides.length < 2 || !confirm("این اسلاید حذف شود؟")) return;
    setSlides((a) => a.filter((_, k) => k !== i));
    setCur((c) => Math.max(0, Math.min(c, slides.length - 2)));
  };
  const move = (i: number, d: number) => {
    const j = i + d;
    if (j < 0 || j >= slides.length) return;
    setSlides((a) => { const b = [...a]; [b[i], b[j]] = [b[j], b[i]]; return b; });
    setCur(j);
  };
  const reset = () => {
    if (!confirm("همه ویرایش‌ها پاک شود و ارائه به حالت اولیه برگردد؟")) return;
    localStorage.removeItem(KEY);
    setSlides(initialSlides);
    setCur(0);
  };

  const doExport = async () => {
    setExp({ p: 0, msg: "شروع …" });
    try {
      const { exportPptx } = await import("./lib/pptx");
      await exportPptx(slides, (p, msg) => setExp({ p, msg }));
      setTimeout(() => setExp(null), 1200);
    } catch (err) {
      console.error(err);
      setExp({ p: 0, msg: "خطا در ساخت PPTX: " + (err as Error).message });
      setTimeout(() => setExp(null), 4000);
    }
  };

  const col = PART_COLORS[s.part];
  const Btn = ({ on, onClick, children, tone = "sky" }: { on?: boolean; onClick: () => void; children: React.ReactNode; tone?: string }) => (
    <button onClick={onClick}
      className={"rounded-xl px-3 py-2 text-sm font-bold shadow-sm transition active:scale-95 " +
        (on ? "bg-gradient-to-l from-amber-400 to-orange-500 text-white shadow-md" : tone === "rose" ? "bg-rose-600 text-white hover:bg-rose-700" : tone === "violet" ? "bg-violet-600 text-white hover:bg-violet-700" : "bg-white text-slate-700 ring-1 ring-sky-200 hover:bg-sky-50")}>
      {children}
    </button>
  );

  return (
    <div className="flex h-full flex-col bg-gradient-to-br from-sky-50 via-white to-rose-50 text-slate-800" dir="rtl">
      {!present && (
        <header className="flex flex-wrap items-center gap-2 border-b border-sky-100 bg-white/80 px-4 py-2 backdrop-blur">
          <div className="flex items-center gap-2">
            <span className="heartbeat text-2xl">🫀</span>
            <div className="leading-tight">
              <div className="text-[15px] font-black text-slate-800">قلب مصنوعی · دستگاه‌های کمک‌بطنی · دوقلوی دیجیتال</div>
              <div className="text-[11px] text-slate-500">{total} اسلاید · {imgCount} تصویر واقعی · {vidCount} ویدیو (۱۰ واقعی + ۱۰ شبیه‌سازی)</div>
            </div>
          </div>
          <div className="mr-auto flex flex-wrap items-center gap-2">
            <Btn onClick={toggleFs} tone="rose">▶ شروع ارائه (F)</Btn>
            <Btn on={notesOpen} onClick={() => setNotesOpen((v) => !v)}>{notesOpen ? "📝 متن کنفرانس: روشن" : "📝 متن کنفرانس: خاموش"}</Btn>
            <Btn on={edit} onClick={() => setEdit((v) => !v)}>✏️ {edit ? "پایان ویرایش" : "ویرایش (E)"}</Btn>
            <Btn on={overview} onClick={() => setOverview((v) => !v)}>🗂 فهرست</Btn>
            <Btn onClick={doExport} tone="violet">⬇ خروجی PPTX</Btn>
          </div>
        </header>
      )}

      {edit && !present && (
        <div className="flex flex-wrap items-center gap-2 border-b border-amber-200 bg-amber-50 px-4 py-1.5 text-xs font-bold text-amber-900">
          <span>حالت ویرایش: روی هر متن کلیک کنید و تایپ کنید؛ روی تصاویر دکمه‌های جایگزین/حذف دارند.</span>
          <Btn onClick={addSlide}>＋ اسلاید جدید</Btn>
          <Btn onClick={dupSlide}>⧉ کپی اسلاید</Btn>
          <Btn onClick={() => move(cur, -1)}>↑ بالا</Btn>
          <Btn onClick={() => move(cur, 1)}>↓ پایین</Btn>
          <Btn onClick={() => delSlide()} tone="rose">🗑 حذف</Btn>
          <label className="flex items-center gap-1">ویدیو:
            <select className="max-w-[260px] rounded-lg border border-amber-300 bg-white px-2 py-1" value={s.video || ""} onChange={(e) => patch({ video: e.target.value || undefined })}>
              <option value="">— بدون ویدیو —</option>
              {Object.values(VIDEOS).map((v) => <option key={v.key} value={v.key}>{v.kind === "real" ? "🎥" : "🤖"} {v.title}</option>)}
            </select>
          </label>
          <label className="flex items-center gap-1">قالب:
            <select className="rounded-lg border border-amber-300 bg-white px-2 py-1" value={s.layout} onChange={(e) => patch({ layout: e.target.value as Slide["layout"] })}>
              <option value="content">محتوا</option><option value="gallery">گالری</option><option value="section">بخش</option><option value="quiz">پرسش</option><option value="title">عنوان</option><option value="final">پایانی</option>
            </select>
          </label>
          <Btn onClick={reset}>⟲ بازنشانی</Btn>
        </div>
      )}

      <div className="flex min-h-0 flex-1">
        {overview && !present && (
          <aside className="w-72 shrink-0 overflow-y-auto border-l border-sky-100 bg-white/90 p-2">
            {slides.map((x, i) => (
              <div key={x.id + i} onClick={() => setCur(i)}
                className={"mb-1 flex cursor-pointer items-center gap-2 rounded-xl p-2 text-[13px] transition hover:bg-sky-50 " + (i === cur ? "bg-sky-100 font-bold ring-1 ring-sky-300" : "")}>
                <span className="flex h-7 w-7 shrink-0 items-center justify-center rounded-full text-xs font-black text-white" style={{ background: PART_COLORS[x.part].main }}>{i + 1}</span>
                <span className="line-clamp-2 flex-1">{x.title}</span>
                {x.video && <span title="ویدیو">{VIDEOS[x.video]?.kind === "sim" ? "🤖" : "🎥"}</span>}
                {edit && (
                  <span className="flex gap-0.5">
                    <button onClick={(e) => { e.stopPropagation(); move(i, -1); }} className="rounded bg-slate-200 px-1">↑</button>
                    <button onClick={(e) => { e.stopPropagation(); move(i, 1); }} className="rounded bg-slate-200 px-1">↓</button>
                    <button onClick={(e) => { e.stopPropagation(); delSlide(i); }} className="rounded bg-rose-500 px-1 text-white">×</button>
                  </span>
                )}
              </div>
            ))}
          </aside>
        )}

        <main className="relative flex min-w-0 flex-1 flex-col">
          <div className="h-1.5 w-full bg-sky-100">
            <div className="h-full transition-all duration-500" style={{ width: ((cur + 1) / total) * 100 + "%", background: col.main }} />
          </div>
          <div ref={stageBox} className="relative flex min-h-0 flex-1 items-center justify-center p-1">
            <div style={{ width: W * scale, height: H * scale }} className="relative shrink-0 overflow-hidden rounded-2xl shadow-2xl ring-1 ring-sky-200">
              <div style={{ width: W, height: H, transform: `scale(${scale})`, transformOrigin: "top right", position: "absolute", top: 0, right: 0 }}>
                <SlideView key={s.id + cur} slide={s} index={cur} total={total} edit={edit} onChange={patch} onOpen={setLight} />
              </div>
            </div>
            {!present && (
              <>
                <button onClick={() => go(-1)} disabled={cur === 0} className="absolute right-2 top-1/2 h-12 w-12 -translate-y-1/2 rounded-full bg-white/90 text-2xl shadow-lg ring-1 ring-sky-200 transition hover:bg-sky-100 disabled:opacity-30">›</button>
                <button onClick={() => go(1)} disabled={cur === total - 1} className="absolute left-2 top-1/2 h-12 w-12 -translate-y-1/2 rounded-full bg-white/90 text-2xl shadow-lg ring-1 ring-sky-200 transition hover:bg-sky-100 disabled:opacity-30">‹</button>
              </>
            )}
          </div>

          {notesOpen && (
            <section className={"border-t-4 bg-white/95 px-5 py-3 " + (present ? "h-40" : "h-44")} style={{ borderColor: col.main }}>
              <div className="mb-1 flex items-center gap-2 text-xs font-black" style={{ color: col.dark }}>
                <span>📝 متن کنفرانس · اسلاید {cur + 1}</span>
                <button onClick={() => setNotesOpen(false)} className="mr-auto rounded-full bg-slate-200 px-3 py-0.5 text-slate-700 hover:bg-slate-300">خاموش کردن (N)</button>
              </div>
              {edit ? (
                <textarea value={s.notes} onChange={(e) => patch({ notes: e.target.value })} className="h-[104px] w-full resize-none rounded-xl border border-amber-300 bg-amber-50 p-2 text-[17px] leading-8 outline-none" />
              ) : (
                <p className="h-[104px] overflow-y-auto text-[19px] leading-9 text-slate-800">{s.notes}</p>
              )}
            </section>
          )}

          {present && (
            <div className="group absolute inset-x-0 bottom-0 flex justify-center pb-2 pt-8 opacity-0 transition hover:opacity-100">
              <div className="flex items-center gap-2 rounded-full bg-slate-900/80 px-4 py-2 text-sm font-bold text-white shadow-xl">
                <button onClick={() => go(-1)} className="px-2">› قبلی</button>
                <span dir="ltr">{cur + 1} / {total}</span>
                <button onClick={() => go(1)} className="px-2">بعدی ‹</button>
                <button onClick={() => setNotesOpen((v) => !v)} className="rounded-full bg-amber-500 px-3 py-1">📝 {notesOpen ? "خاموش" : "روشن"}</button>
                <button onClick={toggleFs} className="rounded-full bg-rose-600 px-3 py-1">✕ خروج</button>
              </div>
            </div>
          )}
        </main>
      </div>

      {light && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/80 p-6" onClick={() => setLight(null)}>
          <img src={light} alt="" className="max-h-full max-w-full rounded-2xl shadow-2xl" referrerPolicy="no-referrer" />
        </div>
      )}

      {exp && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/50 backdrop-blur-sm">
          <div className="w-[420px] rounded-3xl bg-white p-6 text-center shadow-2xl">
            <div className="heartbeat mb-2 text-5xl">🫀</div>
            <div className="mb-3 text-lg font-black">در حال ساخت فایل PowerPoint</div>
            <div className="h-3 w-full overflow-hidden rounded-full bg-sky-100"><div className="h-full rounded-full bg-gradient-to-l from-violet-500 to-sky-500 transition-all" style={{ width: exp.p * 100 + "%" }} /></div>
            <div className="mt-3 text-sm text-slate-600">{exp.msg}</div>
          </div>
        </div>
      )}
    </div>
  );
}
