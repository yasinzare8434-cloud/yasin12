export const PART_COLORS: Record<number, { main: string; soft: string; dark: string; name: string }> = {
  0: { main: "#0ea5e9", soft: "#e0f2fe", dark: "#0369a1", name: "مقدمه" },
  1: { main: "#e11d48", soft: "#ffe4e6", dark: "#9f1239", name: "بخش اول · قلب مصنوعی" },
  2: { main: "#0284c7", soft: "#dbeafe", dark: "#1e3a8a", name: "بخش دوم · کمک‌بطنی (VAD)" },
  3: { main: "#7c3aed", soft: "#ede9fe", dark: "#4c1d95", name: "بخش سوم · دوقلوی دیجیتال" },
};

export const toHex = (c: string) => c.replace("#", "").toUpperCase();
