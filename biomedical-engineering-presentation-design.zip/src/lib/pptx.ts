import PptxGenJS from "pptxgenjs";
import type { Slide } from "../data/types";
import { small, VIDEOS, TOM_JERRY } from "./media";
import { PART_COLORS, toHex } from "./theme";

const DPI = 96;

async function blobToDataUrl(b: Blob, mime?: string): Promise<string> {
  return new Promise((res, rej) => {
    const r = new FileReader();
    r.onload = () => {
      let s = String(r.result);
      if (mime) s = s.replace(/^data:[^;]*;/, `data:${mime};`);
      res(s);
    };
    r.onerror = rej;
    r.readAsDataURL(b);
  });
}

/** fetch an image and crop it ("cover") to the exact box so PowerPoint shows it undistorted */
async function coverImage(url: string, wIn: number, hIn: number, big = false): Promise<string | null> {
  try {
    const src = url.startsWith("data:") || big ? url : small(url);
    const r = await fetch(src, { mode: url.startsWith("data:") ? undefined : "cors" });
    if (!r.ok) return null;
    const bmp = await createImageBitmap(await r.blob());
    const W = Math.round(wIn * DPI * (big ? 1.4 : 1.1)), H = Math.round(hIn * DPI * (big ? 1.4 : 1.1));
    const cv = document.createElement("canvas");
    cv.width = W; cv.height = H;
    const c = cv.getContext("2d")!;
    const k = Math.max(W / bmp.width, H / bmp.height);
    const dw = bmp.width * k, dh = bmp.height * k;
    c.drawImage(bmp, (W - dw) / 2, (H - dh) / 2, dw, dh);
    return cv.toDataURL("image/jpeg", 0.8);
  } catch {
    return null;
  }
}

async function pool<T, R>(items: T[], n: number, fn: (x: T, i: number) => Promise<R>): Promise<R[]> {
  const out: R[] = new Array(items.length);
  let i = 0;
  await Promise.all(
    Array.from({ length: n }, async () => {
      while (i < items.length) {
        const k = i++;
        out[k] = await fn(items[k], k);
      }
    })
  );
  return out;
}

const FONT = "Tahoma";

export async function exportPptx(slides: Slide[], onProgress: (p: number, msg: string) => void) {
  const pptx = new PptxGenJS();
  pptx.layout = "LAYOUT_WIDE";
  pptx.rtlMode = true;
  pptx.title = "قلب مصنوعی، دستگاه‌های کمک‌بطنی و دوقلوی دیجیتال";
  pptx.author = "گروه ارائه‌دهنده";

  // video cache
  const videoCache: Record<string, { data: string; cover: string }> = {};
  const needed = Array.from(new Set(slides.map((s) => s.video).filter(Boolean))) as string[];
  let done = 0;
  const total = slides.length + needed.length;
  for (const key of needed) {
    const v = VIDEOS[key];
    if (!v) continue;
    onProgress(done / total, `آماده‌سازی ویدیو ${key}`);
    const blob = await (await fetch(v.src)).blob();
    const data = (await blobToDataUrl(blob, "video/mp4")).replace(/^data:/, "");
    let cover = "";
    if (v.poster) cover = await blobToDataUrl(await (await fetch(v.poster)).blob(), "image/jpeg");
    videoCache[key] = { data, cover };
    done++;
  }

  let tomPoster: string | null = null;
  try {
    const r = await fetch(TOM_JERRY.poster);
    if (r.ok) tomPoster = await blobToDataUrl(await r.blob(), "image/jpeg");
  } catch {
    /* ignore */
  }

  for (let idx = 0; idx < slides.length; idx++) {
    const s = slides[idx];
    onProgress(done / total, `ساخت اسلاید ${idx + 1} از ${slides.length}`);
    const col = PART_COLORS[s.part];
    const main = toHex(col.main), soft = toHex(col.soft), dark = toHex(col.dark);
    const sl = pptx.addSlide();
    sl.background = { color: "F4F9FF" };
    sl.addShape("rect", { x: 0, y: 0, w: 13.333, h: 0.16, fill: { color: main }, line: { color: main } });
    sl.addText(String(idx + 1), { x: 0.3, y: 7.05, w: 0.6, h: 0.3, fontSize: 11, color: "94A3B8", fontFace: FONT });
    sl.addText(col.name, { x: 9.3, y: 7.05, w: 3.7, h: 0.3, fontSize: 11, color: main, bold: true, align: "right", fontFace: FONT, rtlMode: true });
    sl.addNotes(s.notes || "");

    const T = (text: string, o: Record<string, unknown>) =>
      sl.addText(text, { fontFace: FONT, rtlMode: true, lang: "fa-IR", align: "right", valign: "top", ...o } as never);

    const bulletsRuns = (size: number, color = "1E293B") =>
      s.bullets.map((b) => ({
        text: b,
        options: { bullet: { characterCode: "25CF", indent: 18 }, rtlMode: true, fontSize: size, color, breakLine: true, paraSpaceAfter: 10, align: "right" as const },
      }));

    const imgs = await pool(s.images, 6, async (u, i) => {
      // sizes resolved later by layout, here we only fetch raw once to reuse for each layout
      void i;
      return u;
    });

    const place = async (urls: string[], boxes: { x: number; y: number; w: number; h: number }[]) => {
      const res = await pool(urls.slice(0, boxes.length), 6, (u, i) => coverImage(u, boxes[i].w, boxes[i].h, boxes[i].w > 3));
      res.forEach((d, i) => {
        if (d) sl.addImage({ data: d, ...boxes[i], rounding: false });
        else sl.addShape("roundRect", { ...boxes[i], fill: { color: soft }, line: { color: soft } });
      });
    };

    if (s.layout === "title") {
      T("بِسْمِ اللَّهِ الرَّحْمَٰنِ الرَّحِيم", { x: 1, y: 0.35, w: 11.33, h: 0.9, fontSize: 38, bold: true, align: "center", color: "B7791F" });
      T(s.title, { x: 0.9, y: 1.5, w: 11.5, h: 2.0, fontSize: 38, bold: true, align: "center", color: dark, valign: "middle" });
      T(s.bullets.join("   ·   "), { x: 1, y: 3.55, w: 11.33, h: 0.6, fontSize: 18, align: "center", color: "334155" });
      if (s.subtitle) T(s.subtitle, { x: 1, y: 4.2, w: 11.33, h: 0.5, fontSize: 16, align: "center", color: main, bold: true });
      const bw = 1.45, gap = 0.1, x0 = (13.333 - (bw * 8 + gap * 7)) / 2;
      await place(imgs, imgs.slice(0, 8).map((_, i) => ({ x: x0 + i * (bw + gap), y: 5.0, w: bw, h: 1.85 })));
    } else if (s.layout === "section") {
      T(s.subtitle || "", { x: 8.3, y: 0.8, w: 4.6, h: 1.8, fontSize: 96, bold: true, color: main, align: "right" });
      T(s.title, { x: 6.6, y: 2.5, w: 6.3, h: 1.6, fontSize: 32, bold: true, color: dark });
      T(s.bullets.join("\n"), { x: 6.6, y: 4.2, w: 6.3, h: 1.6, fontSize: 18, color: "334155" });
      const cw = 1.55, ch = 1.9, g = 0.1;
      await place(imgs, imgs.slice(0, 8).map((_, i) => ({ x: 0.5 + (i % 4) * (cw + g), y: 0.9 + Math.floor(i / 4) * (ch + g), w: cw, h: ch })));
      await Promise.resolve();
    } else if (s.layout === "gallery") {
      T(s.title, { x: 5.5, y: 0.3, w: 7.4, h: 0.8, fontSize: 28, bold: true, color: dark, valign: "middle" });
      const cw = 2.4, ch = 1.38, g = 0.1, x0 = 0.4;
      await place(imgs, imgs.slice(0, 20).map((_, i) => ({ x: x0 + (i % 5) * (cw + g), y: 1.25 + Math.floor(i / 5) * (ch + g), w: cw, h: ch })));
    } else if (s.layout === "quiz") {
      T(s.title, { x: 1, y: 0.4, w: 11.33, h: 0.9, fontSize: 34, bold: true, align: "center", color: dark });
      s.bullets.forEach((q, i) => {
        sl.addShape("roundRect", { x: 1, y: 1.6 + i * 1.8, w: 11.33, h: 1.55, fill: { color: i === 0 ? "FFE4E6" : i === 1 ? "DBEAFE" : "EDE9FE" }, line: { color: i === 0 ? "E11D48" : i === 1 ? "0284C7" : "7C3AED", width: 2 }, rectRadius: 0.2 });
        T(q, { x: 1.3, y: 1.6 + i * 1.8, w: 10.8, h: 1.55, fontSize: 20, valign: "middle", color: "1E293B", bold: true });
      });
    } else if (s.layout === "final") {
      T(s.title, { x: 6.2, y: 0.4, w: 6.7, h: 0.9, fontSize: 34, bold: true, color: dark });
      T(s.subtitle || "", { x: 6.2, y: 1.35, w: 6.7, h: 0.6, fontSize: 20, bold: true, color: main });
      T("اعضای گروه:", { x: 6.2, y: 2.05, w: 6.7, h: 0.5, fontSize: 18, bold: true, color: "334155" });
      T(s.bullets.join("\n"), { x: 6.2, y: 2.55, w: 6.7, h: 2.6, fontSize: 20, color: "1E293B", paraSpaceAfter: 6 });
      sl.addShape("roundRect", { x: 6.2, y: 5.4, w: 6.7, h: 1.2, fill: { color: "FFF7E6" }, line: { color: "D69E2E", width: 2.5 }, rectRadius: 0.2 });
      T(s.extra || "", { x: 6.2, y: 5.4, w: 6.7, h: 1.2, fontSize: 26, bold: true, color: "B7791F", align: "center", valign: "middle" });
      // Tom & Jerry frame
      sl.addShape("roundRect", { x: 0.4, y: 0.7, w: 5.5, h: 5.9, fill: { color: "FEF3C7" }, line: { color: "F59E0B", width: 4 }, rectRadius: 0.3 });
      T("۵ دقیقه استراحت!  تام و جری", { x: 0.5, y: 0.8, w: 5.3, h: 0.7, fontSize: 22, bold: true, color: "B45309", align: "center" });
      if (tomPoster) sl.addImage({ data: tomPoster, x: 0.8, y: 1.6, w: 4.7, h: 3.5, sizing: { type: "contain", w: 4.7, h: 3.5 } });
      sl.addText("▶ پخش ویدیو تام و جری (کلیک کنید)", {
        x: 0.8, y: 5.3, w: 4.7, h: 0.8, fontFace: FONT, fontSize: 18, bold: true, align: "center", color: "FFFFFF",
        fill: { color: "F59E0B" }, hyperlink: { url: TOM_JERRY.page, tooltip: "Tom and Jerry" }, shape: "roundRect" as never,
      } as never);
    } else {
      // content
      T(s.title, { x: 7.3, y: 0.4, w: 5.65, h: 1.1, fontSize: 26, bold: true, color: dark, valign: "middle" });
      sl.addShape("rect", { x: 11.0, y: 1.5, w: 1.95, h: 0.06, fill: { color: main }, line: { color: main } });
      sl.addText(bulletsRuns(18) as never, { x: 7.3, y: 1.75, w: 5.65, h: 5.0, fontFace: FONT, rtlMode: true, lang: "fa-IR", align: "right", valign: "top" } as never);
      const X = 0.35, Y = 0.5, Wd = 6.7, Hd = 6.4, g = 0.1;
      const cw = (Wd - 3 * g) / 4, ch = (Hd - 2 * g) / 3;
      const cell = (r: number, c: number) => ({ x: X + c * (cw + g), y: Y + r * (ch + g), w: cw, h: ch });
      if (s.video && videoCache[s.video]) {
        const vb = { x: X, y: Y, w: Wd, h: 2 * ch + g };
        const v = videoCache[s.video];
        sl.addMedia({ type: "video", x: vb.x, y: vb.y, w: vb.w, h: vb.h, data: v.data, extn: "mp4", cover: v.cover || undefined } as never);
        await place(imgs, [0, 1, 2, 3].map((c) => cell(2, c)));
      } else {
        const big = { x: X, y: Y, w: 2 * cw + g, h: 2 * ch + g };
        const smalls = [cell(0, 2), cell(0, 3), cell(1, 2), cell(1, 3), cell(2, 0), cell(2, 1), cell(2, 2), cell(2, 3)];
        await place(imgs, [big, ...smalls]);
      }
    }
    done++;
  }

  onProgress(0.97, "در حال ساخت فایل PPTX …");
  await pptx.writeFile({ fileName: "قلب-مصنوعی-VAD-دوقلوی-دیجیتال.pptx" });
  onProgress(1, "انجام شد");
}
