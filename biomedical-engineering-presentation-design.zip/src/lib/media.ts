import raw from "../data/images.json";

const WM = "https://upload.wikimedia.org/wikipedia/commons/";
const px = (id: number) => `https://images.pexels.com/photos/${id}/pexels-photo-${id}.jpeg?auto=compress&cs=tinysrgb&w=960`;

type Raw = Record<string, { u: string; t: string; r: number }[]>;
const wiki = raw as Raw;

const stock: Record<string, number[]> = {
  dt: [12489156, 8386366, 8090133, 8090132, 8090302, 8090294, 12719396, 8439076],
  ai: [39192393, 48604, 8376340, 5355868],
  heartanat: [9228364, 5207102, 5207116, 3825539],
  ecg: [8460089, 8460126, 9099821],
  iot: [39459348, 20897585, 8943283, 39824872, 39459346, 4483340, 4416539],
  transplant: [39459349, 24022825, 20217786, 20217787, 7583367, 4769122, 24193884, 8853183],
  print3d: [18296466, 30275792, 26969660, 26969628, 9574516, 19895784, 11679113],
};

const fallback: Record<string, string[]> = {
  heartanat: ["failure", "transplant", "ecg"],
  tah: ["lvad", "valve", "transplant", "heartanat"],
  transplant: ["failure", "heartanat", "hlm"],
  valve: ["tah", "cath", "transplant", "heartanat"],
  hlm: ["transplant", "ecmo", "iot", "tah"],
  failure: ["heartanat", "ecg", "pacemaker"],
  lvad: ["tah", "ecmo", "pacemaker", "iabp", "hlm", "heartanat", "iot"],
  iabp: ["ecmo", "cath", "ecg", "iot", "lvad"],
  ecmo: ["iot", "hlm", "lvad", "iabp"],
  pacemaker: ["ecg", "cath", "lvad"],
  cath: ["pacemaker", "valve", "ecg", "mri"],
  ecg: ["pacemaker", "heartanat", "iot", "wear"],
  dt: ["ai", "mri", "vr", "print3d", "cfd"],
  mri: ["dt", "ecg", "cath", "iot"],
  cfd: ["dt", "mri", "ai", "heartanat", "vr"],
  print3d: ["dt", "vr", "ai", "tah"],
  vr: ["dt", "ai", "print3d", "iot"],
  wear: ["ecg", "ai", "iot", "dt"],
  ai: ["dt", "vr", "wear", "mri", "print3d"],
  iot: ["ecg", "wear", "ai", "vr", "ecmo"],
};

const pool: Record<string, string[]> = {};
for (const k of Object.keys(fallback)) {
  pool[k] = [...(stock[k] || []).map(px), ...(wiki[k] || []).map((x) => WM + x.u)];
}

const used = new Set<string>();
const wrap: Record<string, number> = {};

/** Pick n images for a topic: unique across the deck while possible. */
export function pickImages(topic: string, n: number): string[] {
  const chain = [topic, ...(fallback[topic] || [])];
  const out: string[] = [];
  for (const k of chain) {
    for (const u of pool[k] || []) {
      if (out.length >= n) break;
      if (!used.has(u)) {
        used.add(u);
        out.push(u);
      }
    }
    if (out.length >= n) break;
  }
  // wrap-around (reuse) when everything was consumed
  let guard = 0;
  while (out.length < n && guard++ < 200) {
    const p = pool[topic] && pool[topic].length ? pool[topic] : pool.heartanat;
    const i = (wrap[topic] = (wrap[topic] || 0) + 1);
    const u = p[i % p.length];
    if (!out.includes(u)) out.push(u);
  }
  return out;
}

export const small = (u: string) => u.replace("/960px-", "/500px-").replace("w=960", "w=560");

// ---- videos (inlined by vite) ----
const mp4 = import.meta.glob("../assets/video/*.mp4", { eager: true, query: "?url", import: "default" }) as Record<string, string>;
const jpg = import.meta.glob("../assets/video/*.jpg", { eager: true, query: "?url", import: "default" }) as Record<string, string>;

const base = (p: string) => p.split("/").pop()!.replace(/\.\w+$/, "");

export type VideoInfo = { key: string; src: string; poster: string; title: string; kind: "real" | "sim"; credit: string; file: string };

const titles: Record<string, string> = {
  "real-01": "ضربان قلب روی مانیتور بیمار",
  "real-02": "پایش ضربان قلب بیمار در بیمارستان",
  "real-03": "اکوکاردیوگرافی؛ تصویربرداری سونوگرافی از قلب",
  "real-04": "جراحی قلب باز در اتاق عمل",
  "real-05": "جراح حین عمل قلب",
  "real-06": "هولوگرام ECG و بررسی دیجیتال توسط پزشک",
  "real-07": "جریان گلبول‌های قرمز در رگ",
  "real-08": "انیمیشن سه‌بعدی قلب انسان",
  "real-09": "مدل دیجیتال چهره انسان (دوقلوی دیجیتال)",
  "real-10": "پایش ضربان قلب با ساعت هوشمند",
  "sim-01": "شبیه‌سازی هوش مصنوعی: چرخه قلبی",
  "sim-02": "شبیه‌سازی هوش مصنوعی: قلب مصنوعی کامل (TAH)",
  "sim-03": "شبیه‌سازی هوش مصنوعی: عملکرد LVAD",
  "sim-04": "شبیه‌سازی هوش مصنوعی: پمپ گریز از مرکز با معلق‌سازی مغناطیسی",
  "sim-05": "شبیه‌سازی هوش مصنوعی: بالون داخل آئورتی (IABP)",
  "sim-06": "شبیه‌سازی هوش مصنوعی: مدار ECMO",
  "sim-07": "شبیه‌سازی هوش مصنوعی: دوقلوی دیجیتال بدن",
  "sim-08": "شبیه‌سازی هوش مصنوعی: دینامیک سیالات محاسباتی در آئورت",
  "sim-09": "شبیه‌سازی هوش مصنوعی: کنترل هوشمند حلقه‌بسته پمپ",
  "sim-10": "شبیه‌سازی هوش مصنوعی: شوک ICD و بازگشت ریتم",
};

export const VIDEOS: Record<string, VideoInfo> = {};
for (const [p, src] of Object.entries(mp4)) {
  const file = base(p);
  const key = file.startsWith("sim") ? file.slice(0, 6) : file;
  const posterEntry = Object.entries(jpg).find(([q]) => base(q) === file);
  VIDEOS[key] = {
    key,
    src,
    poster: posterEntry ? posterEntry[1] : "",
    title: titles[key] || file,
    kind: key.startsWith("sim") ? "sim" : "real",
    credit: key.startsWith("sim") ? "ساخته‌شده با شبیه‌ساز گرافیکی / هوش مصنوعی" : "ویدیوی واقعی (Pexels)",
    file: file + ".mp4",
  };
}

export const TOM_JERRY = {
  src: "https://archive.org/download/cco_TomandJerryPianoTooners/TomJerry_Piano_Tooners_512kb.mp4",
  page: "https://archive.org/details/cco_TomandJerryPianoTooners",
  poster: "https://archive.org/services/img/cco_TomandJerryPianoTooners",
};
