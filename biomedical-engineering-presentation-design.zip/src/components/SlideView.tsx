import { useRef } from "react";
import type { Slide } from "../data/types";
import { PART_COLORS } from "../lib/theme";
import { Chip, EcgDeco, Ed, Pic, TomJerryFrame, VideoBox, readFile } from "./parts";

type Props = {
  slide: Slide; index: number; total: number; edit: boolean;
  onChange: (p: Partial<Slide>) => void; onOpen: (u: string) => void;
};

export default function SlideView({ slide: s, index, total, edit, onChange, onOpen }: Props) {
  const col = PART_COLORS[s.part];
  const addRef = useRef<HTMLInputElement>(null);

  const setBullet = (i: number, v: string) => onChange({ bullets: s.bullets.map((b, k) => (k === i ? v : b)) });
  const delBullet = (i: number) => onChange({ bullets: s.bullets.filter((_, k) => k !== i) });
  const addBullet = () => onChange({ bullets: [...s.bullets, "نکته جدید"] });
  const setImg = (i: number, u: string) => onChange({ images: s.images.map((x, k) => (k === i ? u : x)) });
  const delImg = (i: number) => onChange({ images: s.images.filter((_, k) => k !== i) });

  const pic = (i: number, cls = "", big = false) => {
    const u = s.images[i];
    if (!u) return <div key={"e" + i} className={"rounded-xl bg-white/50 " + cls} />;
    return <Pic key={i + u.slice(-24)} src={u} big={big} edit={edit} onReplace={(v) => setImg(i, v)} onRemove={() => delImg(i)} onOpen={onOpen} className={cls} />;
  };

  const AddImg = (
    edit && (
      <>
        <button onClick={() => addRef.current?.click()} className="absolute bottom-3 left-3 z-20 rounded-full bg-amber-500 px-4 py-1.5 text-sm font-bold text-white shadow-lg">＋ افزودن تصویر</button>
        <input ref={addRef} type="file" accept="image/*" hidden onChange={async (e) => { const f = e.target.files?.[0]; if (f) onChange({ images: [...s.images, await readFile(f)] }); e.target.value = ""; }} />
      </>
    )
  );

  const Bg = (
    <>
      <div className="absolute inset-0" style={{ background: `linear-gradient(135deg, #ffffff 0%, ${col.soft} 100%)` }} />
      <div className="absolute -left-24 -top-24 h-72 w-72 rounded-full opacity-40 blur-3xl" style={{ background: col.main }} />
      <div className="absolute -bottom-32 -right-20 h-80 w-80 rounded-full bg-rose-300 opacity-30 blur-3xl" />
      <div className="absolute bottom-0 left-0 right-0 h-16 opacity-25"><EcgDeco color={col.main} className="h-full w-full" /></div>
    </>
  );

  const Header = (
    <div className="absolute inset-x-0 top-0 z-10 flex items-center justify-between px-8 pt-4">
      <Chip color={col.main}>{col.name}</Chip>
      <div className="flex items-center gap-3 text-sm font-bold text-slate-500">
        <span className="heartbeat text-xl">❤️</span>
        <span dir="ltr">{index + 1} / {total}</span>
      </div>
    </div>
  );

  const Bullets = (cls: string) => (
    <ul className={cls}>
      {s.bullets.map((b, i) => (
        <li key={i} className="pop flex items-start gap-3" style={{ animationDelay: i * 90 + "ms" }}>
          <span className="mt-1.5 flex h-8 w-8 shrink-0 items-center justify-center rounded-full text-sm font-black text-white shadow" style={{ background: col.main }}>{i + 1}</span>
          <Ed value={b} edit={edit} onChange={(v) => setBullet(i, v)} className="flex-1 text-slate-800" tag="span" />
          {edit && <button onClick={() => delBullet(i)} className="shrink-0 rounded-full bg-rose-500 px-2 text-white">×</button>}
        </li>
      ))}
      {edit && <button onClick={addBullet} className="rounded-xl bg-amber-500 px-4 py-1 text-sm font-bold text-white">＋ افزودن نکته</button>}
    </ul>
  );

  let body: React.ReactNode = null;

  if (s.layout === "title") {
    body = (
      <div className="absolute inset-0 flex flex-col items-center px-14 pt-12">
        <div className="gold-text text-[64px] font-black leading-[1.4]">بِسْمِ اللَّهِ الرَّحْمَٰنِ الرَّحِيمِ</div>
        <div className="mb-3 flex items-center gap-3">
          <div className="h-[3px] w-40 rounded bg-gradient-to-l from-amber-400 to-transparent" />
          <span className="heartbeat text-4xl">❤️</span>
          <div className="h-[3px] w-40 rounded bg-gradient-to-r from-amber-400 to-transparent" />
        </div>
        <Ed tag="h1" value={s.title} edit={edit} onChange={(v) => onChange({ title: v })} className="max-w-[1050px] bg-gradient-to-l from-rose-600 via-fuchsia-600 to-sky-600 bg-clip-text text-center text-[50px] font-black leading-[1.35] text-transparent" />
        <div className="mt-4 flex flex-wrap justify-center gap-3">
          {s.bullets.map((b, i) => (
            <Ed key={i} value={b} edit={edit} onChange={(v) => setBullet(i, v)} className="rounded-full bg-white px-6 py-2 text-[22px] font-bold text-slate-700 shadow-md" />
          ))}
        </div>
        {s.subtitle && <Ed value={s.subtitle} edit={edit} onChange={(v) => onChange({ subtitle: v })} className="mt-3 text-[20px] font-bold text-sky-700" />}
        <div className="absolute inset-x-8 bottom-8 flex justify-center gap-3">
          {s.images.slice(0, 8).map((_, i) => (
            <div key={i} className="floaty h-[170px] w-[140px]" style={{ ["--r" as string]: (i % 2 ? 3 : -3) + "deg", animationDelay: i * 0.35 + "s" }}>
              {pic(i, "h-full w-full border-4 border-white")}
            </div>
          ))}
        </div>
      </div>
    );
  } else if (s.layout === "section") {
    body = (
      <div className="absolute inset-0 flex gap-10 p-12 pt-20">
        <div className="relative flex flex-1 flex-col justify-center">
          <div className="absolute -top-6 right-0 select-none text-[260px] font-black leading-none opacity-20" style={{ color: col.main }}>{s.subtitle}</div>
          <Ed tag="h1" value={s.title} edit={edit} onChange={(v) => onChange({ title: v })} className="relative text-[56px] font-black leading-tight" />
          <div className="my-4 h-1.5 w-40 rounded" style={{ background: col.main }} />
          {s.bullets.map((b, i) => (
            <Ed key={i} tag="p" value={b} edit={edit} onChange={(v) => setBullet(i, v)} className={i === 0 ? "text-[30px] font-bold" : "mt-2 text-[24px] text-slate-600"} />
          ))}
        </div>
        <div className="grid h-full w-[640px] grid-cols-4 grid-rows-2 gap-3">
          {Array.from({ length: 8 }, (_, i) => pic(i, "h-full w-full"))}
        </div>
        {AddImg}
      </div>
    );
  } else if (s.layout === "gallery") {
    body = (
      <div className="absolute inset-0 flex flex-col p-6 pt-16">
        <div className="mb-3 flex items-center gap-4">
          <Ed tag="h1" value={s.title} edit={edit} onChange={(v) => onChange({ title: v })} className="text-[36px] font-black" />
          <div className="flex flex-1 flex-wrap justify-end gap-2">
            {s.bullets.map((b, i) => (
              <Ed key={i} value={b} edit={edit} onChange={(v) => setBullet(i, v)} className="rounded-full px-4 py-1 text-[15px] font-bold text-white" />
            ))}
          </div>
        </div>
        <div className="grid flex-1 grid-cols-5 grid-rows-4 gap-2.5">
          {Array.from({ length: Math.max(20, s.images.length) }, (_, i) => pic(i, "h-full w-full")).slice(0, 20)}
        </div>
        {AddImg}
      </div>
    );
  } else if (s.layout === "quiz") {
    const tints = ["from-rose-100 to-rose-50 border-rose-400", "from-sky-100 to-sky-50 border-sky-400", "from-violet-100 to-violet-50 border-violet-400"];
    body = (
      <div className="absolute inset-0 flex flex-col items-center p-12 pt-20">
        <div className="mb-1 text-[70px] heartbeat">❓</div>
        <Ed tag="h1" value={s.title} edit={edit} onChange={(v) => onChange({ title: v })} className="mb-6 text-[48px] font-black" />
        <div className="flex w-full max-w-[1100px] flex-col gap-5">
          {s.bullets.map((q, i) => (
            <div key={i} className={"pop flex items-center gap-5 rounded-3xl border-2 bg-gradient-to-l p-5 shadow-lg " + tints[i % 3]} style={{ animationDelay: i * 200 + "ms" }}>
              <div className="flex h-16 w-16 shrink-0 items-center justify-center rounded-full bg-white text-3xl font-black shadow" style={{ color: col.main }}>{["۱", "۲", "۳"][i] || i + 1}</div>
              <Ed value={q.replace(/^[۱۲۳\d]\)\s*/, "")} edit={edit} onChange={(v) => setBullet(i, v)} className="text-[26px] font-bold leading-10 text-slate-800" />
              {edit && <button onClick={() => delBullet(i)} className="rounded-full bg-rose-500 px-2 text-white">×</button>}
            </div>
          ))}
        </div>
      </div>
    );
  } else if (s.layout === "final") {
    body = (
      <div className="absolute inset-0 flex gap-8 p-10 pt-16">
        <div className="flex w-[600px] flex-col">
          <Ed tag="h1" value={s.title} edit={edit} onChange={(v) => onChange({ title: v })} className="text-[48px] font-black leading-tight text-sky-900" />
          <Ed value={s.subtitle || ""} edit={edit} onChange={(v) => onChange({ subtitle: v })} className="mt-2 inline-block w-fit rounded-2xl bg-sky-600 px-5 py-2 text-[26px] font-bold text-white shadow-lg" />
          <div className="mb-2 mt-4 text-[20px] font-bold text-slate-500">اعضای گروه:</div>
          <div className="grid grid-cols-2 gap-3">
            {s.bullets.map((b, i) => (
              <div key={i} className="pop flex items-center gap-2 rounded-2xl bg-white px-4 py-3 shadow-md ring-1 ring-sky-100" style={{ animationDelay: i * 120 + "ms" }}>
                <span className="text-2xl">{["🫀", "🧬", "⚙️", "🩺", "💡"][i % 5]}</span>
                <Ed value={b} edit={edit} onChange={(v) => setBullet(i, v)} className="text-[23px] font-bold text-slate-800" />
                {edit && <button onClick={() => delBullet(i)} className="mr-auto rounded-full bg-rose-500 px-2 text-white">×</button>}
              </div>
            ))}
            {edit && <button onClick={addBullet} className="rounded-2xl bg-amber-500 py-2 font-bold text-white">＋ عضو جدید</button>}
          </div>
          <div className="mt-auto rounded-3xl border-[3px] border-double border-amber-400 bg-gradient-to-l from-amber-50 via-white to-amber-50 p-5 text-center shadow-xl">
            <Ed value={s.extra || ""} edit={edit} onChange={(v) => onChange({ extra: v })} className="gold-text text-[40px] font-black" />
          </div>
        </div>
        <div className="flex-1 pt-4"><TomJerryFrame /></div>
      </div>
    );
  } else {
    // content
    const hasVideo = !!s.video;
    body = (
      <div className="absolute inset-0 flex gap-7 p-8 pt-16">
        <div className="flex w-[455px] shrink-0 flex-col rounded-3xl bg-white/85 p-6 shadow-xl ring-1 ring-white backdrop-blur">
          <Ed tag="h1" value={s.title} edit={edit} onChange={(v) => onChange({ title: v })} className="text-[34px] font-black leading-[1.45]" />
          <div className="mb-4 mt-2 h-1.5 w-28 rounded" style={{ background: col.main }} />
          {Bullets("flex flex-col gap-4 text-[21px] font-medium leading-9")}
        </div>
        <div className="relative grid flex-1 grid-cols-4 grid-rows-3 gap-2.5">
          {hasVideo ? (
            <>
              <VideoBox vkey={s.video!} className="col-span-4 row-span-2" />
              {Array.from({ length: 4 }, (_, i) => pic(i, "h-full w-full"))}
            </>
          ) : (
            <>
              {pic(0, "col-span-2 row-span-2 h-full w-full", true)}
              {Array.from({ length: 8 }, (_, i) => pic(i + 1, "h-full w-full"))}
            </>
          )}
          {AddImg}
        </div>
      </div>
    );
  }

  return (
    <div className="slide-anim relative h-full w-full overflow-hidden" dir="rtl">
      {Bg}
      {body}
      {Header}
    </div>
  );
}
