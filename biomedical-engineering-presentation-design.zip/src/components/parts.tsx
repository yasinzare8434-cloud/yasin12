import { useRef, useState } from "react";
import type { ReactNode } from "react";
import { VIDEOS, small, TOM_JERRY } from "../lib/media";

export function Ed({
  value, edit, onChange, className = "", tag = "span",
}: { value: string; edit: boolean; onChange: (v: string) => void; className?: string; tag?: "span" | "div" | "h1" | "h2" | "p" }) {
  const Tag = tag as "span";
  if (!edit) return <Tag className={className}>{value}</Tag>;
  return (
    <Tag
      className={className + " rounded px-1 cursor-text outline-dashed outline-1 outline-amber-400"}
      contentEditable
      suppressContentEditableWarning
      onBlur={(e) => onChange((e.currentTarget as HTMLElement).innerText.replace(/\n+$/, ""))}
    >
      {value}
    </Tag>
  );
}

export function readFile(f: File): Promise<string> {
  return new Promise((res) => {
    const r = new FileReader();
    r.onload = () => res(String(r.result));
    r.readAsDataURL(f);
  });
}

export function Pic({
  src, big, edit, onReplace, onRemove, onOpen, className = "", style,
}: {
  src: string; big?: boolean; edit: boolean; onReplace: (u: string) => void; onRemove: () => void; onOpen: (u: string) => void; className?: string; style?: React.CSSProperties;
}) {
  const [err, setErr] = useState(false);
  const fileRef = useRef<HTMLInputElement>(null);
  return (
    <div className={"group relative overflow-hidden rounded-xl bg-sky-100 shadow-md ring-1 ring-white/70 " + className} style={style}>
      {!err ? (
        <img
          src={big ? src : small(src)}
          alt=""
          loading="lazy"
          referrerPolicy="no-referrer"
          onError={() => setErr(true)}
          onClick={() => !edit && onOpen(src)}
          className="h-full w-full cursor-zoom-in object-cover transition duration-500 group-hover:scale-105"
        />
      ) : (
        <div className="flex h-full w-full items-center justify-center bg-gradient-to-br from-sky-100 to-rose-100 text-3xl">🫀</div>
      )}
      {edit && (
        <div className="absolute inset-x-0 bottom-0 flex gap-1 bg-black/60 p-1 text-[11px] text-white">
          <button className="flex-1 rounded bg-amber-500 py-0.5" onClick={() => fileRef.current?.click()}>جایگزین</button>
          <button className="flex-1 rounded bg-rose-600 py-0.5" onClick={onRemove}>حذف</button>
          <input ref={fileRef} type="file" accept="image/*" hidden onChange={async (e) => { const f = e.target.files?.[0]; if (f) onReplace(await readFile(f)); }} />
        </div>
      )}
    </div>
  );
}

export function VideoBox({ vkey, className = "", compact }: { vkey: string; className?: string; compact?: boolean }) {
  const v = VIDEOS[vkey];
  const ref = useRef<HTMLVideoElement>(null);
  if (!v) return null;
  const real = v.kind === "real";
  const portrait = vkey === "real-08";
  return (
    <div className={"group relative overflow-hidden rounded-2xl bg-slate-900 shadow-xl ring-2 " + (real ? "ring-emerald-400" : "ring-violet-400") + " " + className}>
      {portrait && <img src={v.poster} alt="" className="absolute inset-0 h-full w-full scale-110 object-cover opacity-40 blur-xl" />}
      <video
        ref={ref}
        src={v.src}
        poster={v.poster}
        autoPlay
        muted
        loop
        playsInline
        controls
        className={"relative h-full w-full " + (portrait ? "object-contain" : "object-cover")}
      />
      <div className={"pointer-events-none absolute right-3 top-3 rounded-full px-3 py-1 text-[13px] font-bold text-white shadow " + (real ? "bg-emerald-500" : "bg-violet-600")}>
        {real ? "🎥 ویدیوی واقعی" : "🤖 شبیه‌سازی هوش مصنوعی"}
      </div>
      <div className="absolute left-3 top-3 flex gap-2 opacity-0 transition group-hover:opacity-100">
        <a href={v.src} download={v.file} className="rounded-full bg-white/95 px-3 py-1 text-[13px] font-bold text-slate-800 shadow hover:bg-amber-300" title="دانلود ویدیو">⬇ دانلود</a>
        <button onClick={() => ref.current?.requestFullscreen?.()} className="rounded-full bg-white/95 px-3 py-1 text-[13px] font-bold text-slate-800 shadow hover:bg-amber-300">⛶</button>
      </div>
      {!compact && (
        <div className="pointer-events-none absolute inset-x-0 bottom-9 bg-gradient-to-t from-black/70 to-transparent px-4 pb-2 pt-6 text-sm font-bold text-white">{v.title}</div>
      )}
    </div>
  );
}

export function TomJerryFrame() {
  return (
    <div className="relative flex h-full flex-col rounded-[28px] bg-gradient-to-br from-amber-100 via-orange-50 to-yellow-100 p-4 shadow-2xl ring-[6px] ring-amber-400">
      <div className="absolute -top-4 right-6 rounded-full bg-amber-500 px-5 py-1.5 text-lg font-black text-white shadow-lg">۵ دقیقه استراحت!</div>
      <div className="mb-2 mt-3 text-center text-2xl font-black text-amber-800">🐱 تام و جری 🐭</div>
      <video src={TOM_JERRY.src} poster={TOM_JERRY.poster} controls preload="none" playsInline className="w-full flex-1 rounded-2xl bg-black object-contain shadow-inner" />
      <div className="mt-3 flex gap-2 text-sm font-bold">
        <a href={TOM_JERRY.src} download className="flex-1 rounded-xl bg-amber-500 py-2 text-center text-white shadow hover:bg-amber-600">⬇ دانلود ویدیو</a>
        <a href={TOM_JERRY.page} target="_blank" rel="noreferrer" className="flex-1 rounded-xl bg-white py-2 text-center text-amber-700 shadow hover:bg-amber-50">منبع (Archive.org)</a>
      </div>
    </div>
  );
}

export function EcgDeco({ color, className = "" }: { color: string; className?: string }) {
  return (
    <svg viewBox="0 0 1200 80" className={className} preserveAspectRatio="none">
      <path className="ecg-line" fill="none" stroke={color} strokeWidth="3" strokeLinecap="round" strokeLinejoin="round"
        d="M0 40 H180 L205 40 L225 12 L250 68 L272 40 H420 L440 40 L460 30 L480 40 H640 L660 40 L680 4 L705 76 L730 40 H900 L925 40 L945 22 L965 40 H1200" />
    </svg>
  );
}

export function Chip({ children, color }: { children: ReactNode; color: string }) {
  return <span className="rounded-full px-4 py-1 text-[15px] font-bold text-white shadow" style={{ background: color }}>{children}</span>;
}
